import java.awt.Color;

//class to hold all constant colours used in the game
public class ColorManager {

    //I was supposed to add more colours, but I didn't really have the time 
    //right now there is only the light yellow and the dark yellow colours of the game
    public static final Color LIGHT_YELLOW = new Color(254, 214, 111);

    public static final Color DARK_YELLOW = new Color(245, 184, 27);
    
}
